import requests

from tkinter import *
from random import randint as rnd
from tkinter import messagebox

window = Tk()
window.geometry("1600x900")

helper=""

def CreateBlock():
    global helper
    url=messageLink.get()
    if url=="": 
        url="https://www.youtube.com/channel/UCu2BxoeCflV9yaYpnNhey8w"

    r=requests.get(url)
    HtmlT=r.text.lower()
    NewHtmlT=HtmlT
    results=[]
    for x in range(HtmlT.count("text")):
        a=NewHtmlT.find("text")
        NewHtmlT=NewHtmlT[0:a]+"0"+NewHtmlT[a+1:len(NewHtmlT)]

        result=HtmlT[a+7:a+NewHtmlT[a+7:len(NewHtmlT)].find('"')+7]
        if len(result)<30 and result!="":
           print(str(x)+". "+result)

        results.append(result)
    nomer=0
    for i in range(len(results)):
        if results[i].find(messageText.get())!=-1:
            nomer=i
            
    value = results[nomer]
    helper= results[nomer-1]
    
    LabName["text"]=value
    UpdateBlock()
    create["text"]="ReCreate"
def UpdateBlock():
    
    url=messageLink.get()
    if url=="": 
        url="https://www.youtube.com/channel/UCu2BxoeCflV9yaYpnNhey8w"

    r=requests.get(url)
    HtmlT=r.text.lower()
    NewHtmlT=HtmlT
    results=[]
    for x in range(HtmlT.count("text")):
        a=NewHtmlT.find("text")
        NewHtmlT=NewHtmlT[0:a]+"0"+NewHtmlT[a+1:len(NewHtmlT)]

        result=HtmlT[a+7:a+NewHtmlT[a+7:len(NewHtmlT)].find('"')+7]

        results.append(result)
    nomer=0
    for i in range(len(results)):
        if results[i].find(messageText.get())!=-1:
            nomer=i
            
    value = results[nomer]
    LabName["text"]=value
    window.after(5000, UpdateBlock)

messageLink = StringVar()
messageText = StringVar()
link=Entry(textvariable=messageLink)
search=Entry(textvariable=messageText)
create=Button(window,text="Create", command =CreateBlock)

LabName=Label(window,text="Что хотите собирать?")
LabLink=Label(window,text="Cсылку на сайт:")
LabText=Label(window,text="Текстовое поле:")
LabPage=Label(window,text="LinkPage")
LabPage.config(font=("Courier", 40))
LabLink.config(font=("Courier", 15))
LabText.config(font=("Courier", 15))
LabName.config(font=("Courier", 25))
create.config(font=("Courier", 25))
LabPage.pack()
LabLink.place(x=10,y=0)
link.place(x=210,y=7)
LabText.place(x=10,y=30)
search.place(x=210,y=37)
create.place(x=10,y=70,width=325,height=50)

LabName.pack()


window.mainloop()
